// DOM Elements
const connectionPanel = document.getElementById('connectionPanel');
const chatContainer = document.getElementById('chatContainer');
const apiEndpointInput = document.getElementById('apiEndpoint');
const agentIdInput = document.getElementById('agentId');
const connectBtn = document.getElementById('connectBtn');
const statusText = document.getElementById('statusText');
const status = document.getElementById('status');
const messagesDiv = document.getElementById('messages');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');

// State
let currentApiEndpoint = null;
let currentAgentId = null;
const DEFAULT_AGENT_ALIAS_ID = 'TSTALIASID';

let currentAgentAlias = DEFAULT_AGENT_ALIAS_ID;
let sessionId = generateSessionId();
let isLoading = false;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadFromLocalStorage();
    const shouldAutoConnect = loadFromUrlParams();
    setupEventListeners();
    
    if (shouldAutoConnect) {
        handleConnect();
    }
});

function setupEventListeners() {
    connectBtn.addEventListener('click', handleConnect);
    sendBtn.addEventListener('click', handleSend);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !isLoading) {
            handleSend();
        }
    });
}

// Handle Connect
async function handleConnect() {
    const apiEndpoint = apiEndpointInput.value.trim();
    const agentId = agentIdInput.value.trim();

    if (!apiEndpoint) {
        showError('Lambda Function URL을 입력해주세요.');
        return;
    }

    if (!agentId) {
        showError('Agent ID를 입력해주세요.');
        return;
    }

    // Validate Lambda URL format
    if (!apiEndpoint.startsWith('http')) {
        showError('Lambda Function URL은 https://로 시작해야 합니다.');
        return;
    }

    // Validate Agent ID format (basic check)
    if (agentId.length < 10) {
        showError('올바른 Agent ID를 입력해주세요.');
        return;
    }

    currentApiEndpoint = apiEndpoint;
    currentAgentId = agentId;
    currentAgentAlias = DEFAULT_AGENT_ALIAS_ID;
    
    // Save to localStorage
    saveToLocalStorage();
    updateUrlWithParams(currentAgentId, currentApiEndpoint);

    // Update UI
    connectionPanel.style.display = 'none';
    chatContainer.style.display = 'flex';
    
    updateStatus('connected', '연결됨');
    
    // Clear previous messages and add welcome
    clearMessages();
    addBotMessage('안녕하세요! 서울금융고 안내 도우미입니다. 서울금융고에 대해 궁금한 것을 물어보세요! 😊');
}

// Handle Disconnect
function handleDisconnect() {
    currentApiEndpoint = null;
    currentAgentId = null;
    currentAgentAlias = DEFAULT_AGENT_ALIAS_ID;
    sessionId = generateSessionId();
    
    connectionPanel.style.display = 'block';
    chatContainer.style.display = 'none';
    
    updateStatus('disconnected', '연결 대기 중');
    clearUrlParams();
}

// Handle Send Message
async function handleSend() {
    const message = messageInput.value.trim();
    
    if (!message || isLoading) return;
    
    // Generate new session ID for each message
    sessionId = generateSessionId();
    
    // Add user message to chat
    addUserMessage(message);
    messageInput.value = '';
    
    // Show loading
    isLoading = true;
    const loadingId = addLoadingMessage();
    
    try {
        // Call API
        const response = await invokeAgent(message);
        
        // Remove loading
        removeMessage(loadingId);
        
        // Add bot response
        addBotMessage(response);
        
    } catch (error) {
        // Remove loading
        removeMessage(loadingId);
        
        // Show error
        addBotMessage(`오류가 발생했습니다: ${error.message}`);
        console.error('Error:', error);
    } finally {
        isLoading = false;
    }
}

// Invoke Agent API (Lambda Function URL)
async function invokeAgent(input) {
    const response = await fetch(currentApiEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            agentId: currentAgentId,
            agentAliasId: currentAgentAlias,
            sessionId: sessionId,
            input: input
        })
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Agent 호출에 실패했습니다.');
    }

    const data = await response.json();
    return data.response;
}

// UI Helper Functions
function addUserMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user';
    messageDiv.innerHTML = `
        <div class="message-content">
            <div class="message-bubble">${escapeHtml(text)}</div>
            <div class="message-time">${getTimeString()}</div>
        </div>
        <div class="message-avatar">👻</div>
    `;
    messagesDiv.appendChild(messageDiv);
    scrollToBottom();
}

function addBotMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot';
    messageDiv.innerHTML = `
        <div class="message-avatar">🎃</div>
        <div class="message-content">
            <div class="message-bubble">${escapeHtml(text)}</div>
            <div class="message-time">${getTimeString()}</div>
        </div>
    `;
    messagesDiv.appendChild(messageDiv);
    scrollToBottom();
}

function addLoadingMessage() {
    const id = `loading-${Date.now()}`;
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot';
    messageDiv.id = id;
    messageDiv.innerHTML = `
        <div class="message-avatar">🎃</div>
        <div class="message-content">
            <div class="message-bubble loading">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    `;
    messagesDiv.appendChild(messageDiv);
    scrollToBottom();
    return id;
}

function removeMessage(id) {
    const messageDiv = document.getElementById(id);
    if (messageDiv) {
        messageDiv.remove();
    }
}

function clearMessages() {
    messagesDiv.innerHTML = '';
}

function updateStatus(type, text) {
    statusText.textContent = text;
    status.className = `status ${type}`;
}

function showError(message) {
    alert(message);
}

function scrollToBottom() {
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

// LocalStorage Functions
function saveToLocalStorage() {
    localStorage.setItem('apiEndpoint', currentApiEndpoint);
    localStorage.setItem('agentId', currentAgentId);
}

function loadFromLocalStorage() {
    const savedApiEndpoint = localStorage.getItem('apiEndpoint');
    const savedAgentId = localStorage.getItem('agentId');
    
    if (savedApiEndpoint) {
        apiEndpointInput.value = savedApiEndpoint;
    }
    if (savedAgentId) {
        agentIdInput.value = savedAgentId;
    }
}

function loadFromUrlParams() {
    const params = new URLSearchParams(window.location.search);
    const endpointFromUrl = params.get('endpoint')?.trim();
    const agentIdFromUrl = params.get('agentId')?.trim();
    let readyToConnect = false;

    if (endpointFromUrl) {
        apiEndpointInput.value = endpointFromUrl;
        localStorage.setItem('apiEndpoint', endpointFromUrl);
    }

    if (agentIdFromUrl) {
        agentIdInput.value = agentIdFromUrl;
        localStorage.setItem('agentId', agentIdFromUrl);
    }

    if (endpointFromUrl && agentIdFromUrl) {
        readyToConnect = true;
    }

    return readyToConnect;
}

function updateUrlWithParams(agentId, endpoint) {
    try {
        const url = new URL(window.location.href);
        url.searchParams.set('agentId', agentId);
        url.searchParams.set('endpoint', endpoint);
        window.history.replaceState({}, '', url);
    } catch (error) {
        console.warn('URL 업데이트 실패:', error);
    }
}

function clearUrlParams() {
    try {
        const url = new URL(window.location.href);
        url.searchParams.delete('agentId');
        url.searchParams.delete('endpoint');
        window.history.replaceState({}, '', url);
    } catch (error) {
        console.warn('URL 초기화 실패:', error);
    }
}

// Utility Functions
function generateSessionId() {
    return `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function getTimeString() {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Log on page load
console.log('서울금융고 학교 안내 챗봇 웹앱이 로드되었습니다.');
console.log('연결 준비 완료!');
